@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~dp0Fix_Windows_INI.bat\"\"' -Verb RunAs"
    exit /b
)

echo Configuring directories and STONEHDS.INI for SEEK2...

rem Create seek2dat junctions so both paths work
if not exist "%~dp0seek2dat" mkdir "%~dp0seek2dat"
if not exist "%~dp0seek2dat\cg24" mklink /J "%~dp0seek2dat\cg24" "%~dp0cg24" >nul 2>&1
if not exist "%~dp0seek2dat\cg08" mklink /J "%~dp0seek2dat\cg08" "%~dp0cg08" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir = '%~dp0'; if (-not $dir.EndsWith('\')) { $dir += '\' }; $ini = [System.IO.Path]::Combine($env:WINDIR, 'STONEHDS.INI'); $sjis = [System.Text.Encoding]::GetEncoding(932); $title = $sjis.GetString([byte[]](0x82,0x72,0x82,0x64,0x82,0x64,0x82,0x6A,0x82,0x51)) + ' -SADISTIC BABYLON-'; $cfg = \"[PIL.SEEK2]`r`nREADME=0`r`nGDIR=$dir`r`nSYSTEM=0`r`nGRAPH=2`r`nCG_INSTALL=1`r`nVGA_MODE=0`r`nSHORTCUT=0`r`nTITLE=$title`r`nCD=$dir`r`nPATH=$dir`r`nDEMO_INSTALL=1\"; if (Test-Path $ini) { $txt = [System.IO.File]::ReadAllText($ini, $sjis); if ($txt -match '\[PIL\.SEEK2\]') { $txt = [regex]::Replace($txt, '(?s)\[PIL\.SEEK2\].*?(?=(\r?\n\[|$))', $cfg.Trim()); } else { $txt = $txt.TrimEnd() + \"`r`n`r`n\" + $cfg.Trim() + \"`r`n\"; } } else { $txt = $cfg.Trim() + \"`r`n\"; }; [System.IO.File]::WriteAllText($ini, $txt, $sjis); Write-Host 'STONEHDS.INI configuration applied successfully!';"

echo.
echo ========================================================
echo Setup complete!
echo You can now launch seek2.exe with Locale Emulator.
echo ========================================================
echo.
pause
